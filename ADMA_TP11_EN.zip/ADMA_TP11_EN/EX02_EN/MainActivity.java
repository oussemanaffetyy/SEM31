package com.stat.process;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final int IMG_REV_BON = R.drawable.rev_bon;
    public static final int IMG_REV_MAUVAIS = R.drawable.rev_mauvais;
    public static final int IMG_REV_TRES_MAUVAIS = R.drawable.rev_tres_mauvais;
    private TextView tvEtat;
    private ImageView imgEtat;
    private BroadcastReceiver br;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvEtat=findViewById(R.id.tvEtat);
        imgEtat = findViewById(R.id.imgEtat);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
       
    }

 

}
