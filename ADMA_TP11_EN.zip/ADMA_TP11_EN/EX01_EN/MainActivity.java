package com.anal.visage;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.google.android.gms.vision.face.Landmark;

public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbYDF;
    private TextView tvNbYGF;
    private TextView tvDOM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        imgVisages=(ImageView)findViewById(R.id.imgVisages);
        btnAnalyser=(Button)findViewById(R.id.btnAnalyser);
        tvNbV=(TextView)findViewById(R.id.tvNbV);
        tvNbYDF=(TextView)findViewById(R.id.tvNbYDF);
        tvNbYGF=(TextView)findViewById(R.id.tvNbYGF);
        tvDOM=(TextView)findViewById(R.id.tvDOM);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        
    }

    
}
