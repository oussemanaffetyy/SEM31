		Travail demandé
		
1- Ajouter la fonctionnalité recherche à l'application GestionBib

2- Programmer l'application Guide_Pharmacie

3- Programmer l'application Medecin_Specialite