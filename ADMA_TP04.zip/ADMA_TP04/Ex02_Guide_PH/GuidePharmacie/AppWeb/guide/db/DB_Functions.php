<?php
 
class DB_Functions {
 
    private $db;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	/**
     * Ajouter Livre
    */
    public function ajouterPharmacie($nom,$type,$route, $dcv) {
        $result = mysql_query("INSERT INTO pharmacie(nom,type,route,dcv) VALUES('$nom','$type','$route', $dcv)")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
		
    }
	
   /**
     * Get Livre
    */
    public function rechercherPharmacie($type,$route) {
		$result = mysql_query("SELECT * FROM pharmacie where type='$type' AND route='$route' Order By dcv Asc;")or die(mysql_error());
		$aPh=array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$ph=array();
			$ph["id"]=$row['id'];
			$ph["nom"]=$row['nom'];
			$ph["type"]=$row['type'];
			$ph["route"]=$row['route'];
			$ph["dcv"]=$row['dcv'];			
			$aPh[]=$ph;
			$reponse=array();
			$reponse["liste"]=$aPh;
		}
		echo json_encode($reponse);
		mysql_free_result($result);
    }
	
	public function close() {
		$this->db->close();
	}
}
 
?>