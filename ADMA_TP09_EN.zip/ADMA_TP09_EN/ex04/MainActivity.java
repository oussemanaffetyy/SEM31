package com.anal.visage;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.google.android.gms.vision.face.Landmark;

public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbVS;
    private TextView tvNbVI;
    private TextView tvDYM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        imgVisages=(ImageView)findViewById(R.id.imgVisages);
        btnAnalyser=(Button)findViewById(R.id.btnAnalyser);
        tvNbV=(TextView)findViewById(R.id.tvNbV);
        tvNbVS=(TextView)findViewById(R.id.tvNbVS);
        tvNbVI=(TextView)findViewById(R.id.tvNbVI);
        tvDYM=(TextView)findViewById(R.id.tvDYM);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        btnAnalyser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                analyser();
            }
        });
    }

    private void analyser() {
        Bitmap bitmap = ((BitmapDrawable) imgVisages.getDrawable()).getBitmap();
        FaceDetector.Builder b = new FaceDetector.Builder(this);
        b.setTrackingEnabled(true);
        b.setLandmarkType(FaceDetector.ALL_LANDMARKS);
        b.setClassificationType(FaceDetector.ALL_CLASSIFICATIONS);
        FaceDetector detector = b.build();
        Frame frame = new Frame.Builder().setBitmap(bitmap).build();
        SparseArray<Face> faces = detector.detect(frame);
        int nbV=faces.size();
        int nbVS=0;
        int nbVI=0;
        double dymMax=0;

        for (int i = 0; i < faces.size(); ++i) {
            Face face = faces.valueAt(i);
            if(face.getIsSmilingProbability()>0.5f)
                nbVS++;
            if(face.getEulerZ()>20)
                nbVI++;


            double xLE = 0, yLE = 0, xRE = 0, yRE = 0;

            for (Landmark l : face.getLandmarks()) {
                if (l.getType() == Landmark.LEFT_EYE) {
                    xLE = l.getPosition().x;
                    yLE = l.getPosition().y;
                }
                if (l.getType() == Landmark.RIGHT_EYE) {
                    xRE = l.getPosition().x;
                    yRE = l.getPosition().y;
                }
            }
            double dym = Math.sqrt(Math.pow(xLE - xRE, 2) + Math.pow(yLE - yRE, 2));
            if(dym>dymMax)
                dymMax=dym;
        }
        tvNbV.setText(nbV+"");
        tvNbVS.setText(nbVS+"");
        tvNbVI.setText(nbVI+"");
        tvDYM.setText(dymMax+"");
    }
}
