package com.anal.visage;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.google.android.gms.vision.face.Landmark;

public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbVS;
    private TextView tvNbVI;
    private TextView tvDYM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        imgVisages=(ImageView)findViewById(R.id.imgVisages);
        btnAnalyser=(Button)findViewById(R.id.btnAnalyser);
        tvNbV=(TextView)findViewById(R.id.tvNbV);
        tvNbVS=(TextView)findViewById(R.id.tvNbVS);
        tvNbVI=(TextView)findViewById(R.id.tvNbVI);
        tvDYM=(TextView)findViewById(R.id.tvDYM);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        btnAnalyser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                analyser();
            }
        });
    }

    private void analyser() {
      
    }
}
