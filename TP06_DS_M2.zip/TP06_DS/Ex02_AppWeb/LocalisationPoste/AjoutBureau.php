<?php
	if (isset($_POST['nom']) && isset($_POST['cp'])&& isset($_POST['lat'])&& isset($_POST['lon'])&& isset($_POST['nomGouv'])) {
		$nom = $_POST['nom'];
		$cp = $_POST['cp'];
		$lat = $_POST['lat'];
		$lon = $_POST['lon'];
		$nomGouv = $_POST['nomGouv'];
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterBureau($nom, $cp,$lat,$lon,$nomGouv);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>