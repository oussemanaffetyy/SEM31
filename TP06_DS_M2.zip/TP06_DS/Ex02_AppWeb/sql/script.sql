create table gouv (
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nom text NOT NULL,
		lat DOUBLE,
		lon DOUBLE
);
create table bureau (
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nom text NOT NULL,
		cp INTEGER,
        lat DOUBLE,
		lon DOUBLE,
		nom_gouv text NOT NULL
);


