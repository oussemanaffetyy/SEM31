package radio.com.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final int AJOUT = 1;
    private static final int MODIF = 2;
    private Button btnAjouter;
    private Button btnQuitter;
    private ListView lstT;
    private ArrayAdapter<Tache> adpT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnAjouter=findViewById(R.id.btnAjout);
        btnQuitter=findViewById(R.id.btnQuitter);
        lstT=findViewById(R.id.lstTache);
        adpT=new ArrayAdapter<Tache>(this,android.R.layout.simple_list_item_1);
        lstT.setAdapter(adpT);
        ajouterEcouteurs();
        remplir();
    }

    private void ajouterEcouteurs() {
        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajouter();
            }
        });
        btnQuitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitter();
            }
        });
        lstT.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                modifier(position);
                return false;
            }
        });
    }
    private void remplir() {
        
    }

    private void quitter() {
        finish();
    }

    private void ajouter() {
        Intent i = new Intent(this,Ajout.class);
        startActivityForResult(i,AJOUT);
    }
    private void modifier(int position) {
       
    }

   


}
