package com.contact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class Ajout extends AppCompatActivity {
    private EditText edNom;
    private EditText edPrenom;
    private EditText edNumero;
    private Button btnAjouter;
    private Button btnAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
        initActivity();
    }

    private void initActivity() {
        edNom=findViewById(R.id.edNom);
        edPrenom=findViewById(R.id.edPrenom);
        edNumero=findViewById(R.id.edNumero);
        btnAjouter=findViewById(R.id.btnAjouter);
        btnAnnuler=findViewById(R.id.btnAnnulerA);
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        
    }

   
}