package com.guide;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Ajout extends Activity {
	private EditText edNom;
	private Spinner spType;
	private EditText edRoute;
	private EditText edDcv;
	private Button btnAjouter;
	private ArrayAdapter<String> adpType;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ajout);
		init();
	}

	private void init() {
		edNom = (EditText) findViewById(R.id.edNom);
		spType = (Spinner) findViewById(R.id.spType);
		edRoute = (EditText) findViewById(R.id.edRoute);
		edDcv = (EditText) findViewById(R.id.edDcv);
		btnAjouter = (Button) findViewById(R.id.btnAjouter);
		adpType= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
		adpType.add("Jour");
		adpType.add("Nuit");
		adpType.add("Garde");
		spType.setAdapter(adpType);
		
		ajouterEcouteur();
	}

	private void ajouterEcouteur() {
		

	}

	protected void ajouter() {
		
	}

	
}
