package com.example.presloinapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    public static final int[] TAB_PRES = new int[]{R.drawable.pres00,R.drawable.pres01,R.drawable.pres02,R.drawable.pres03};
    public static final int[] TAB_LOIN = new int[]{R.drawable.loin00,R.drawable.loin01,R.drawable.loin02,R.drawable.loin03};
    private TextView tvProx;
    private ImageView imgPL;
    private SensorManager mg;
    private Sensor acc;
    private Sensor prox;
    private int indiceCourant;
    private static final int NORME_REF=15;
    private boolean estChange;
    private double xD,xF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        tvProx=findViewById(R.id.tvProx);
        imgPL = findViewById(R.id.imgPL);
        mg= (SensorManager) getSystemService(SENSOR_SERVICE);
        acc=mg.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        prox=mg.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        indiceCourant=0;

        actualiser(0);
        ajouterecouteurs();
    }


    @Override
    protected void onResume() {
        mg.registerListener(this,acc,SensorManager.SENSOR_DELAY_UI);
        mg.registerListener(this,prox,SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }

    @Override
    protected void onPause() {
        mg.unregisterListener(this,acc);
        mg.unregisterListener(this,prox);
        super.onPause();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        switch(sensorEvent.sensor.getType()){
            case Sensor.TYPE_ACCELEROMETER:
                float x= sensorEvent.values[0];
                float y= sensorEvent.values[1];
                float z= sensorEvent.values[2];
                double norme=Math.sqrt(Math.pow(x,2)+Math.pow(y,2)+Math.pow(z,2));

            case Sensor.TYPE_PROXIMITY:
                float p= sensorEvent.values[0];
                actualiser(p);
                break;
        }
    }

    private void ajouterecouteurs() {
        imgPL.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                suivant();
                return false;
            }
        });
    }

    private void suivant() {
        indiceCourant=(indiceCourant+1)%TAB_LOIN.length;

    }

    private void actualiser(float p) {
        if(p==0)
            imgPL.setImageResource(TAB_LOIN[indiceCourant]);
        else
            imgPL.setImageResource(TAB_PRES[indiceCourant]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
