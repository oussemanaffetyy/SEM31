package com.contact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Modification extends AppCompatActivity {
    private EditText edNom;
    private EditText edPrenom;
    private EditText edNumero;
    private Button btnModifier;
    private Button btnAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modification);
        initActivity();
    }

    private void initActivity() {
        edNom=findViewById(R.id.edNomM);
        edPrenom=findViewById(R.id.edPrenomM);
        edNumero=findViewById(R.id.edNumeroM);
        btnModifier=findViewById(R.id.btnModifier);
        btnAnnuler=findViewById(R.id.btnAnnulerM);
        remplirChamps();
        ajouterEcouteurs();
    }

    private void remplirChamps() {
       
    }

    private void ajouterEcouteurs() {
        
    }

    
}