PowerManager pm;
PowerManager.WakeLock wl;
@SuppressLint("InvalidWakeLockTag")
    
        
        

pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"satish");
wl.acquire();
wl.release();

           
  