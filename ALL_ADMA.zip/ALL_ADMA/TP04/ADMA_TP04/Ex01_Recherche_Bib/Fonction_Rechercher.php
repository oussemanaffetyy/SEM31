<?php
public function rechercher($titre) {
        $result = mysql_query("SELECT * FROM livre where titre like '%$titre%' order by titre;")or die(mysql_error());
		$aLivre=array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$livre=array();
			$livre["id"]=$row['id'];
			$livre["titre"]=$row['titre'];
			$livre["nbPage"]=$row['nbpage'];			
			$aLivre[]=$livre;
			$reponse=array();
			$reponse["resultat"]=$aLivre;
		}
		echo json_encode($reponse);
		mysql_free_result($result);
    }
	
?>