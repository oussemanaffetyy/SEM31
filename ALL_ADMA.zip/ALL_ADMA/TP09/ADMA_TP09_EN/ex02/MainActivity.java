package acc.com.visage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.io.InputStream;

import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.google.android.gms.vision.face.FaceDetector.Builder;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private Button btnSuivant;
    private ToggleButton tglVisible;
    private FaceView fView;

  
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnSuivant = (Button) findViewById(R.id.btnSuivant);
        tglVisible = (ToggleButton) findViewById(R.id.tglVisible);
        fView = (FaceView) findViewById(R.id.fView);

        
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
        

    }

    private void detecter(boolean afficherInfo) {

        
    }

    
}
