<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../jqm/jquery.mobile-1.4.4.min.css">
<script src="../jqm/jquery-1.11.1.min.js"></script>
<script src="../jqm/jquery.mobile-1.4.4.min.js"></script>
</head>
<body>
<?php

	if (isset($_GET['livre']) && isset($_GET['titre']) && isset($_GET['nbPage'])) {
		$id = $_GET['livre'];
		$titre = $_GET['titre'];
		$nbPage = $_GET['nbPage'];
			 
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->modifierLivre($id,$titre, $nbPage);
		//header('Location: ModificationForm.php');
		//exit();
		echo "<META http-equiv='refresh' content='0;URL=ModificationForm.php'>";
	   
	} else {
		header('Location: ModificationFormError.php');
		 exit();
	}
?>
</body>
</html>