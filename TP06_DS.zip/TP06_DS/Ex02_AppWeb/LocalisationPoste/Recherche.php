<?php
	


if ( isset($_POST['nomG'])&& isset($_POST['nomB'])) {
		$nomG = $_POST['nomG'];
		$nomB = $_POST['nomB'];
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->rechercherPharmacie($nomG,$nomB);
		
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}	
?>	
