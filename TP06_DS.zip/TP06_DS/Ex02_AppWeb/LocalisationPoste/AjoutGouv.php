<?php
	if (isset($_POST['nom']) && isset($_POST['lat'])&& isset($_POST['lon']))) {
		$nom = $_POST['nom'];
		$lat = $_POST['lat'];
		$lon = $_POST['lon'];
		
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterGouv($nom, $lat,$lon);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>